The MetCraft_Demo.zip comprises of a demo pipeline and the following four sets of data.
1. The first set consists of metabolomics data acquired in the positive mode along with the group annotation information to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Differential Analysis module.

2. The second set consists of metabolomics data acquired in the positive mode along with the group annotation information to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Differential Analysis module.

3. The third set consists of metabolomics data acquired in the negative mode along with the group annotation information to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Differential Analysis module.

4. The fourth set consists of metabolomics and proteomics data acquired from overlapping set of samples along with the group annotation information to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Omics integration Module.