The MetCraft_Demo.zip comprises of a demo pipeline and the following four sets of data.
1. The first set consists of preprocessed metabolomics data acquired in the positive mode (1_metabolomics_data_pos.csv) and a group annotation file (1_metabolomics_group.csv) to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Differential Analysis module.

2. The second set consists of preprocessed metabolomics data acquired in the positive mode (2_metabolomics_data_pos.csv) and a group annotation file (2_metabolomics_group.csv) to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Differential Analysis module.


3. The third set consists of preprocessed metabolomics data acquired in the negative mode (3_metabolomics_data_neg.csv) and a group annotation file (3_metabolomics_group.csv) to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Differential Analysis module.

4. The fourth set consists of preprocessed metabolomics data (4_metabolomics_data_pos.csv) and proteomics data acquired from overlapping set of samples and two group annotation files (4_metabolomics_group.csv and 4_proteomics_group.csv) to test a set of modules in a pipeline starting from the Mass-Based Search module and ending with the Omics integration Module.